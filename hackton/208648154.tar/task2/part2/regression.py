import ast
import re

import pandas as pd
import sklearn
import itertools
import numpy as np
from sklearn.metrics import f1_score
import plotly.graph_objects as go
from sklearn.metrics import mean_squared_error as mse
from sklearn.ensemble import RandomForestRegressor

BASIC_STAGE = 'אבחנה-Basic stage'
DIAGNOSTIC_DATE = 'אבחנה-Diagnosis date'
LYMPHOVASCULAR = 'אבחנה-Ivi -Lymphovascular invasion'
METASTASES_MARK = 'אבחנה-M -metastases mark (TNM)'
MARGIN_TYPE = 'אבחנה-Margin Type'
SIDE_TYPE = 'אבחנה-Side'
STAGE = 'אבחנה-Stage'
POSITIVE_NODES = 'אבחנה-Positive nodes'
TUMOR_DEPTH = 'אבחנה-Tumor depth'
TUMOR_WIDTH = 'אבחנה-Tumor width'
FROM_NAME = ' Form Name'
LABEL_DICT = {}
TRAIN_LABELS = {'LYM - Lymph nodes', 'BON - Bones', 'SKI - Skin',
                'HEP - Hepatic',
                'PLE - Pleura', 'PUL - Pulmonary', 'BRA - Brain',
                'MAR - Bone Marrow',
                'ADR - Adrenals', 'OTH - Other', 'PER - Peritoneum'}


def parse_HER2(word):
    neg_set = {"eg", "-", "akhkh", "ne", "שלי", "_", "no"}
    pos_set = {"pos", "os", "+", "חי", "po", "yes", "amp"}
    for n in neg_set:
        if n in word.lower():
            return -1
    for p in pos_set:
        if p in word.lower():
            return 1
    return 0


def parse_Histopatological_degree(word):
    word = word.lower()
    regex = [["g4", "gx", "un", "not"], ["g3", "poor"], ["g2", "mod"],
             ["g1", "well"]]
    for i in range(len(regex)):
        for pattern in regex[i]:
            if pattern in word:
                return i
    return -1


def parse_KI67(word):
    regx1 = re.match(".*?(\d+).*?(\d+).*", word)
    regx2 = re.match(".*?(\d+).*", word)
    if regx1:
        return np.average([int(i) for i in regx1.groups()])
    elif regx2:
        return regx2.groups()[0]
    if "low" in word.lower():
        return 10
    if "high" in word.lower():
        return 90
    return -1


def parse_TNM(word):
    if "1" in word:
        return 1
    elif "2" in word:
        return 2
    elif "3" in word:
        return 3
    elif "0" in word:
        return 0
    elif "4" in word:
        return 4
    elif "x" in word.lower():
        return 5
    return -1


def parse_Nodes_exam(word):
    if word == "":
        return 6
    return int(word)


def parse_Nodes_exam_pos(word):
    if word == "":
        return 1
    return int(word)


def is_surgery(col1, col2, col3):
    res = []
    for i in range(len(col1)):
        if col1[i] == "" and col2[i] == "" and col3[i] == "":
            res.append(0)
        else:
            res.append(1)
    return pd.Series(data=res)


def parse_er_pr(word):
    word = word.lower()
    strong = {"st"}
    weak = {"חלש", "we"}
    if "eg" in word or "-" in word:
        return 0
    for st in strong:
        if st in word:
            return 3
    for w in weak:
        if w in word:
            return 1

    return 2


def extract_labels(labels_set):
    res = set()
    for lst in labels_set:
        if lst == "":
            continue
        lst = ast.literal_eval(lst)
        for v in lst:
            res.add(v)
    return res


def preprocess_basic_stage(df):
    df[df[BASIC_STAGE] == 'Null'] = np.NaN
    return pd.get_dummies(df, columns=[BASIC_STAGE], prefix='stage')  # here


def preprocess_diagnosis_date(df):
    df['diagnosis_date'] = pd.to_datetime(df[DIAGNOSTIC_DATE])
    return df.drop(columns=DIAGNOSTIC_DATE)


def preprocess_lymphovascular_invasion(df):
    return df.drop(columns=LYMPHOVASCULAR)


def preprocess_metastases_mark(df):
    return pd.get_dummies(df, columns=[METASTASES_MARK],
                          prefix='metastases_mark')


def preprocess_form_name(df):
    return pd.get_dummies(df, columns=[FROM_NAME],
                          prefix='form_name')  # HERE


def preprocess_margin_type(df):
    return pd.get_dummies(df, columns=[MARGIN_TYPE], prefix='margin_type')


def preprocess_side_type(df):
    return pd.get_dummies(df, columns=[SIDE_TYPE], prefix='side')


def preprocess_stage(df):
    df.loc[df[STAGE].isna() & ~(df[POSITIVE_NODES].astype('float').notna() & (
            df[POSITIVE_NODES] > 0.5)), STAGE] = 'Stage1'
    df.loc[df[STAGE].isna() & (df[POSITIVE_NODES].astype('float').notna() & (
            df[POSITIVE_NODES] > 0.5)), STAGE] = 'Stage2a'
    return pd.get_dummies(df, columns=[STAGE], prefix='stage')


def preprocess(df, preprocessors):
    for preprocessor in preprocessors:
        df = preprocessor(df)
    return df


def parse_age(word):
    if word == "":
        return 55
    return float(word)


def update_label_row(df):
    for i, row in df.iterrows():
        my_label = row["metastases_sites_raw"]
        # print(row.index)
        for col in row.index:
            if col in my_label:
                df.at[i, col] = 1
            else:
                df.at[i, col] = 0


def match_columns(df, expected_columns):
    missing_columns = list(set(expected_columns) - set(df.columns))
    excess_columns = list(set(df.columns) - set(expected_columns))
    df[missing_columns] = [0] * len(missing_columns)
    return df.drop(columns=excess_columns)


def parse_data(df_to_parse, training_df=True):
    """
    file_to_be_parsed : .csv path to be parsed.
    """
    if training_df:
        df_to_parse.drop_duplicates()

    # parse data
    df_to_parse = preprocess(df_to_parse, [preprocess_basic_stage,
                                           preprocess_lymphovascular_invasion,
                                           preprocess_metastases_mark,
                                           preprocess_margin_type,
                                           preprocess_side_type,
                                           preprocess_stage,
                                           preprocess_form_name
                                           ])
    df_to_parse = df_to_parse.fillna("")
    df_to_parse["אבחנה-Her2"] = df_to_parse["אבחנה-Her2"].apply(parse_HER2)
    # delete the col diagnosis.
    df_to_parse['אבחנה-Histopatological degree'] = df_to_parse[
        'אבחנה-Histopatological degree']. \
        apply(parse_Histopatological_degree)
    df_to_parse['אבחנה-KI67 protein'] = df_to_parse[
        'אבחנה-KI67 protein'].apply(parse_KI67)
    df_to_parse['אבחנה-N -lymph nodes mark (TNM)'] = df_to_parse[
        'אבחנה-N -lymph nodes mark (TNM)'].apply(parse_TNM)
    df_to_parse['אבחנה-Nodes exam'] = df_to_parse['אבחנה-Nodes exam']. \
        apply(parse_Nodes_exam)
    df_to_parse['אבחנה-Positive nodes'] = df_to_parse['אבחנה-Positive nodes']. \
        apply(parse_Nodes_exam_pos)
    df_to_parse['אבחנה-Age'] = df_to_parse['אבחנה-Age'].apply(parse_age)
    df_to_parse['אבחנה-Surgery sum'] = df_to_parse['אבחנה-Surgery sum'].apply(
        lambda x: 0 if x == "" else x)

    df_to_parse.drop(
        columns=['אבחנה-Surgery date1', 'אבחנה-Lymphatic penetration',
                 'אבחנה-Surgery name3',
                 'surgery before or after-Activity date',
                 'id-hushed_internalpatientid', ' Hospital',
                 # 'Unnamed: 0', DIAGNOSTIC_DATE,
                 'אבחנה-Surgery date2', 'אבחנה-Surgery date3',
                 'אבחנה-Surgery name1', 'User Name',
                 'אבחנה-Histological diagnosis'
            , 'אבחנה-Surgery name2', 'אבחנה-Surgery name2',
                 'אבחנה-Tumor depth',
                 'אבחנה-Tumor width'], inplace=True)
    df_to_parse['אבחנה-T -Tumor mark (TNM)'] = df_to_parse[
        'אבחנה-T -Tumor mark (TNM)'] \
        .apply(parse_TNM)

    df_to_parse['אבחנה-er'] = df_to_parse['אבחנה-er'].apply(parse_er_pr)
    df_to_parse['אבחנה-pr'] = df_to_parse['אבחנה-pr'].apply(parse_er_pr)

    # make sure dummies cover all possible features in the df_to_parse
    surgery_before_or_after_activity = {'כירו-שד-למפקטומי+בלוטות',
                                        'שד-כריתה בגישה זעירה דרך העטרה',
                                        'שד-כריתה בגישה זעירה+בלוטות',
                                        'כירורגיה-שד למפקטומי',
                                        'כירו-שד-מסטקטומי+בלוטות',
                                        'כירו-שד-למפקטומי+בלוטות+קרינה תוך '
                                        'ניתוחית (intrabeam)',
                                        'כירור-הוצאת בלוטות לימפה',
                                        'כיר-שד-הוצ.בלוטות בית שח',
                                        'כירורגיה-שד מסטקטומי',
                                        'כיר-לאפ-הוצ טבעת/שנוי מי'}

    intersect_sur = surgery_before_or_after_activity. \
        difference(
        df_to_parse['surgery before or after-Actual activity'].unique())
    if len(intersect_sur) != 0:
        for val in intersect_sur:
            df_to_parse.loc[len(df_to_parse.index)] = \
                {'surgery before or after-Actual activity': val}

    sub_df = pd.get_dummies(
        df_to_parse['surgery before or after-Actual activity'])
    df_to_parse = pd.concat((df_to_parse, sub_df), axis=1)
    df_to_parse.drop(columns=['surgery before or after-Actual activity'],
                     inplace=True)
    df_to_parse.drop(df_to_parse.tail(len(intersect_sur)).index, inplace=True)

    # Change labels the matrix
    # label_df = pd.DataFrame(data=df_to_parse['metastases_sites_raw'])
    # labels = extract_labels(df_to_parse['metastases_sites_raw'].unique())
    # for label in TRAIN_LABELS:
    #     label_df[label] = [0 for _ in label_df.index]
    # update_label_row(label_df)
    # label_df.drop(columns=['metastases_sites_raw', ], inplace=True)
    # df_to_parse.drop(columns=['metastases_sites_raw', 'is_malignant'], inplace=True)

    # return df_to_parse, label_df, list(labels)
    if training_df:
        df_to_parse = df_to_parse[
            ['אבחנה-Age', 'אבחנה-Her2', 'אבחנה-Histopatological degree',
             'אבחנה-KI67 protein', 'אבחנה-N -lymph nodes mark (TNM)',
             'אבחנה-Nodes exam', 'אבחנה-Positive nodes', 'אבחנה-Surgery sum',
             'אבחנה-T -Tumor mark (TNM)', 'אבחנה-er', 'אבחנה-pr',
             'אבחנה-Tumor size',
             'stage_c - Clinical', 'stage_p - Pathological',
             'metastases_mark_M0',
             'metastases_mark_M1', 'metastases_mark_M1b',
             'metastases_mark_MX', 'metastases_mark_Not yet Established',
             'margin_type_ללא', 'margin_type_נגועים', 'margin_type_נקיים',
             'side_דו צדדי', 'side_ימין', 'side_שמאל', 'stage_LA',
             'stage_Stage0', 'stage_Stage0is',
             'stage_Stage1', 'stage_Stage1b', 'stage_Stage1c',
             'stage_Stage2', 'stage_Stage2a', 'stage_Stage2b', 'stage_Stage3',
             'stage_Stage3a', 'stage_Stage3b', 'stage_Stage3c', 'stage_Stage4',
             'form_name_אומדן סימפטומים ודיווח סיעודי',
             'form_name_אנמנזה סיעודית',
             'form_name_אנמנזה סיעודית קצרה', 'form_name_אנמנזה רפואית',
             'form_name_ביקור במרפאה',
             'form_name_ביקור במרפאה המטו-אונקולוגית',
             'form_name_ביקור במרפאה קרינה', 'form_name_דיווח סיעודי', '',
             'כיר-לאפ-הוצ טבעת/שנוי מי', 'כיר-שד-הוצ.בלוטות בית שח',
             'כירו-שד-למפקטומי+בלוטות',
             'כירו-שד-למפקטומי+בלוטות+קרינה תוך ניתוחית (intrabeam)',
             'כירו-שד-מסטקטומי+בלוטות', 'כירור-הוצאת בלוטות לימפה',
             'כירורגיה-שד למפקטומי', 'כירורגיה-שד מסטקטומי',
             'שד-כריתה בגישה זעירה דרך העטרה', 'שד-כריתה בגישה זעירה+בלוטות']]
    else:
        df_to_parse = df_to_parse[
            ['אבחנה-Age', 'אבחנה-Her2', 'אבחנה-Histopatological degree',
             'אבחנה-KI67 protein', 'אבחנה-N -lymph nodes mark (TNM)',
             'אבחנה-Nodes exam', 'אבחנה-Positive nodes', 'אבחנה-Surgery sum',
             'אבחנה-T -Tumor mark (TNM)', 'אבחנה-er', 'אבחנה-pr',
             'stage_c - Clinical', 'stage_p - Pathological',
             'metastases_mark_M0',
             'metastases_mark_M1',
             'metastases_mark_M1b',
             'metastases_mark_MX', 'metastases_mark_Not yet Established',
             'margin_type_ללא', 'margin_type_נגועים', 'margin_type_נקיים',
             'side_דו צדדי', 'side_ימין', 'side_שמאל', 'stage_LA',
             'stage_Stage0', 'stage_Stage0is',
             'stage_Stage1', 'stage_Stage1b', 'stage_Stage1c',
             'stage_Stage2', 'stage_Stage2a', 'stage_Stage2b', 'stage_Stage3',
             'stage_Stage3a', 'stage_Stage3b', 'stage_Stage3c', 'stage_Stage4',
             'form_name_אומדן סימפטומים ודיווח סיעודי',
             'form_name_אנמנזה סיעודית',
             'form_name_אנמנזה סיעודית קצרה', 'form_name_אנמנזה רפואית',
             'form_name_ביקור במרפאה',
             'form_name_ביקור במרפאה המטו-אונקולוגית',
             'form_name_ביקור במרפאה קרינה', 'form_name_דיווח סיעודי', '',
             'כיר-לאפ-הוצ טבעת/שנוי מי', 'כיר-שד-הוצ.בלוטות בית שח',
             'כירו-שד-למפקטומי+בלוטות',
             'כירו-שד-למפקטומי+בלוטות+קרינה תוך ניתוחית (intrabeam)',
             'כירו-שד-מסטקטומי+בלוטות', 'כירור-הוצאת בלוטות לימפה',
             'כירורגיה-שד למפקטומי', 'כירורגיה-שד מסטקטומי',
             'שד-כריתה בגישה זעירה דרך העטרה', 'שד-כריתה בגישה זעירה+בלוטות']]
    return df_to_parse


def return_dfs(train_feat_file_name, train_labels_file_name,
               test_feats_file_name):
    train_feats_df = pd.read_csv(train_feat_file_name, encoding="UTF-8")
    train_labels_df = pd.read_csv(train_labels_file_name, encoding="UTF-8")
    test_feats_df = pd.read_csv(test_feats_file_name, encoding="UTF-8")
    train_df = pd.concat([train_feats_df, train_labels_df], axis=1)
    return train_df, test_feats_df


if __name__ == "__main__":
    # Train model
    train_df, test_feats_df = return_dfs("train.feats.csv",
                                         "train.labels.1.csv",
                                         "test.feats.csv")  # require
    parsed_train_df = parse_data(train_df)
    parsed_train_df.drop(parsed_train_df[parsed_train_df['אבחנה-Tumor size']
                                         == ''].index, inplace=True)
    parsed_test_feats_df = parse_data(test_feats_df, False)
    train_y = parsed_train_df['אבחנה-Tumor size']
    rf = RandomForestRegressor(n_estimators=100, ccp_alpha=0.01).fit(
        parsed_train_df.drop(columns='אבחנה-Tumor size'), train_y)

    # Predict and save
    predict_y = rf.predict(parsed_test_feats_df)
    data = {'אבחנה-Tumor size': predict_y}
    df_predict_y = pd.DataFrame(data)
    df_predict_y.to_csv("predictions.csv", index=False)
