import ast
import re
import pandas as pd
import numpy as np
from skmultilearn.adapt import MLkNN

BASIC_STAGE = 'אבחנה-Basic stage'
DIAGNOSTIC_DATE = 'אבחנה-Diagnosis date'
LYMPHOVASCULAR = 'אבחנה-Ivi -Lymphovascular invasion'
METASTASES_MARK = 'אבחנה-M -metastases mark (TNM)'
MARGIN_TYPE = 'אבחנה-Margin Type'
SIDE_TYPE = 'אבחנה-Side'
STAGE = 'אבחנה-Stage'
POSITIVE_NODES = 'אבחנה-Positive nodes'
TUMOR_DEPTH = 'אבחנה-Tumor depth'
TUMOR_WIDTH = 'אבחנה-Tumor width'
FROM_NAME = ' Form Name'
LABEL_DICT = {}
TRAIN_LABELS = {'LYM - Lymph nodes', 'BON - Bones', 'SKI - Skin',
                'HEP - Hepatic',
                'PLE - Pleura', 'PUL - Pulmonary', 'BRA - Brain',
                'MAR - Bone Marrow',
                'ADR - Adrenals', 'OTH - Other', 'PER - Peritoneum'}

"""
Parsing function for different features
"""

def parse_HER2(word):
    neg_set = {"eg", "-", "akhkh", "ne", "שלי", "_", "no"}
    pos_set = {"pos", "os", "+", "חי", "po", "yes", "amp"}
    for n in neg_set:
        if n in word.lower():
            return -1
    for p in pos_set:
        if p in word.lower():
            return 1
    return 0


def parse_Histopatological_degree(word):
    word = word.lower()
    regex = [["g4", "gx", "un", "not"], ["g3", "poor"], ["g2", "mod"],
             ["g1", "well"]]
    for i in range(len(regex)):
        for pattern in regex[i]:
            if pattern in word:
                return i
    return -1


def parse_KI67(word):
    regx1 = re.match(".*?(\d+).*?(\d+).*", word)
    regx2 = re.match(".*?(\d+).*", word)
    if regx1:
        return np.average([int(i) for i in regx1.groups()])
    elif regx2:
        return regx2.groups()[0]
    if "low" in word.lower():
        return 10
    if "high" in word.lower():
        return 90
    return -1


def parse_TNM(word):
    if "1" in word:
        return 1
    elif "2" in word:
        return 2
    elif "3" in word:
        return 3
    elif "0" in word:
        return 0
    elif "4" in word:
        return 4
    elif "x" in word.lower():
        return 5
    return -1


def parse_Nodes_exam(word):
    if word == "":
        return 6
    return int(word)


def parse_Nodes_exam_pos(word):
    if word == "":
        return 1
    return int(word)


def is_surgery(col1, col2, col3):
    res = []
    for i in range(len(col1)):
        if col1[i] == "" and col2[i] == "" and col3[i] == "":
            res.append(0)
        else:
            res.append(1)
    return pd.Series(data=res)


def parse_er_pr(word):
    word = word.lower()
    strong = {"st"}
    weak = {"חלש", "we"}
    if "eg" in word or "-" in word:
        return 0
    for st in strong:
        if st in word:
            return 3
    for w in weak:
        if w in word:
            return 1

    return 2


def extract_labels(labels_set):
    res = set()
    for lst in labels_set:
        if lst == "":
            continue
        lst = ast.literal_eval(lst)
        for v in lst:
            res.add(v)
    return res


def preprocess_basic_stage(df):
    df[df[BASIC_STAGE] == 'Null'] = np.NaN
    return pd.get_dummies(df, columns=[BASIC_STAGE], prefix='stage')  # here


def preprocess_diagnosis_date(df):
    df['diagnosis_date'] = pd.to_datetime(df[DIAGNOSTIC_DATE])
    return df.drop(columns=DIAGNOSTIC_DATE)


def preprocess_lymphovascular_invasion(df):
    return df.drop(columns=LYMPHOVASCULAR)


def preprocess_metastases_mark(df):
    return pd.get_dummies(df, columns=[METASTASES_MARK],
                          prefix='metastases_mark')


def preprocess_form_name(df):
    return pd.get_dummies(df, columns=[FROM_NAME],
                          prefix='form_name')  # HERE


def preprocess_margin_type(df):
    return pd.get_dummies(df, columns=[MARGIN_TYPE], prefix='margin_type')


def preprocess_side_type(df):
    return pd.get_dummies(df, columns=[SIDE_TYPE], prefix='side')


def preprocess_stage(df):
    df.loc[df[STAGE].isna() & ~(df[POSITIVE_NODES].astype('float').notna() & (
            df[POSITIVE_NODES] > 0.5)), STAGE] = 'Stage1'
    df.loc[df[STAGE].isna() & (df[POSITIVE_NODES].astype('float').notna() & (
            df[POSITIVE_NODES] > 0.5)), STAGE] = 'Stage2a'
    return pd.get_dummies(df, columns=[STAGE], prefix='stage')


def preprocess(df, preprocessors):
    for preprocessor in preprocessors:
        df = preprocessor(df)
    return df


def parse_age(word):
    if word == "":
        return 55
    return float(word)


def update_label_row(df):
    for i, row in df.iterrows():
        my_label = row["metastases_sites_raw"]
        # print(row.index)
        for col in row.index:
            if col in my_label:
                df.at[i, col] = 1
            else:
                df.at[i, col] = 0


def match_columns(df, expected_columns):
    missing_columns = list(set(expected_columns) - set(df.columns))
    excess_columns = list(set(df.columns) - set(expected_columns))
    df[missing_columns] = [0] * len(missing_columns)
    return df.drop(columns=excess_columns)


def parse_data(file_to_be_parsed: str, train_mode: bool):
    """
    file_to_be_parsed : .csv path to be parsed.
    This is the main parsing function - this creates the train, test,
    and label that were used during development.
    """
    pd.set_option('display.max_columns', None)
    train = pd.read_csv(file_to_be_parsed, encoding="UTF-8")
    train.drop_duplicates()

    # parse data
    train = preprocess(train, [preprocess_basic_stage,
                               preprocess_lymphovascular_invasion,
                               preprocess_metastases_mark,
                               preprocess_margin_type,
                               preprocess_side_type,
                               preprocess_stage,
                               preprocess_form_name
                               ])
    train = train.fillna("")
    train["אבחנה-Her2"] = train["אבחנה-Her2"].apply(parse_HER2)
    # delete the col diagnosis.
    train['אבחנה-Histopatological degree'] = train[
        'אבחנה-Histopatological degree']. \
        apply(parse_Histopatological_degree)
    train['אבחנה-KI67 protein'] = train['אבחנה-KI67 protein'].apply(parse_KI67)
    train['אבחנה-N -lymph nodes mark (TNM)'] = train[
        'אבחנה-N -lymph nodes mark (TNM)'].apply(parse_TNM)
    train['אבחנה-Nodes exam'] = train['אבחנה-Nodes exam']. \
        apply(parse_Nodes_exam)
    train['אבחנה-Positive nodes'] = train['אבחנה-Positive nodes']. \
        apply(parse_Nodes_exam_pos)
    train['אבחנה-Age'] = train['אבחנה-Age'].apply(parse_age)
    train['אבחנה-Surgery sum'] = train['אבחנה-Surgery sum'].apply(
        lambda x: 0 if x == "" else x)

    train.drop(columns=['אבחנה-Surgery date1', 'אבחנה-Lymphatic penetration',
                        'אבחנה-Surgery name3',
                        'surgery before or after-Activity date',
                        'id-hushed_internalpatientid', ' Hospital',
                        DIAGNOSTIC_DATE,
                        'אבחנה-Surgery date2', 'אבחנה-Surgery date3',
                        'אבחנה-Surgery name1', 'User Name',
                        'אבחנה-Histological diagnosis'
        , 'אבחנה-Surgery name2', 'אבחנה-Surgery name2', 'אבחנה-Tumor depth',
                        'אבחנה-Tumor width'], inplace=True)

    # if train_mode:
    #     # 'Unnamed: 0'
    #     train.drop(columns=['Unnamed: 0'], inplace=True)

    train['אבחנה-T -Tumor mark (TNM)'] = train['אבחנה-T -Tumor mark (TNM)'] \
        .apply(parse_TNM)

    train['אבחנה-er'] = train['אבחנה-er'].apply(parse_er_pr)
    train['אבחנה-pr'] = train['אבחנה-pr'].apply(parse_er_pr)

    # make sure dummies cover all possible features in the train
    surgery_before_or_after_activity = {'כירו-שד-למפקטומי+בלוטות',
                                        'שד-כריתה בגישה זעירה דרך העטרה',
                                        'שד-כריתה בגישה זעירה+בלוטות',
                                        'כירורגיה-שד למפקטומי',
                                        'כירו-שד-מסטקטומי+בלוטות',
                                        'כירו-שד-למפקטומי+בלוטות+קרינה תוך '
                                        'ניתוחית (intrabeam)',
                                        'כירור-הוצאת בלוטות לימפה',
                                        'כיר-שד-הוצ.בלוטות בית שח',
                                        'כירורגיה-שד מסטקטומי',
                                        'כיר-לאפ-הוצ טבעת/שנוי מי'}

    intersect_sur = surgery_before_or_after_activity. \
        difference(train['surgery before or after-Actual activity'].unique())
    if len(intersect_sur) != 0:
        for val in intersect_sur:
            train.loc[len(train.index)] = \
                {'surgery before or after-Actual activity': val}

    sub_df = pd.get_dummies(train['surgery before or after-Actual activity'])
    train = pd.concat((train, sub_df), axis=1)
    train.drop(columns=['surgery before or after-Actual activity'],
               inplace=True)
    train.drop(train.tail(len(intersect_sur)).index, inplace=True)

    if train_mode:
        # Change labels the matrix
        label_df = pd.DataFrame(data=train['metastases_sites_raw'])
        labels = extract_labels(train['metastases_sites_raw'].unique())
        for label in TRAIN_LABELS:
            label_df[label] = [0 for _ in label_df.index]
        update_label_row(label_df)
        label_df.drop(columns=['metastases_sites_raw', ], inplace=True)
        train.drop(columns=['metastases_sites_raw'],
                   inplace=True)

        return train, label_df, list(labels)

    else:
        return train, None, None


def extract_output(arr):
    prediction = []
    for i in range(len(arr)):
        val = []
        for j in range(len(arr[0])):
            if arr[i][j] == 1:
                val.append(LABEL_DICT[j])
        # if val != "[":
        #     val = val[:-2]
        # val += "]"
        prediction.append(val)
    res = pd.DataFrame()
    res['אבחנה-Location of distal metastases'] = prediction
    # res.reset_index(drop=True, inplace=True)
    return res



if __name__ == "__main__":
    # X, y, labels = parse_data("train_data.csv", True)


    # test_X, test_y, test_labels = parse_data("test_data.csv", True)
    model = MLkNN(k=25)

    all_data, all_test, labels = parse_data("train.feats.csv", True)
    LABEL_DICT = {i: labels[i] for i in range(len(labels))}

    real_test, _1, _2 = parse_data("test.feats.csv", False)
    to_drop = list(set(all_data.columns).difference(set(real_test.columns)))
    all_data.drop(columns=to_drop, inplace=True)
    model.fit(all_data, all_test.to_numpy())
    pred = model.predict(real_test)
    # create predictions
    extract_output(pred.toarray()).to_csv("prediction.csv", index=False)
