README.txt
USERS.txt
project.pdf

task2/part1/classifier.py
task2/part1/predictions.csv
task2/part1/requirements.txt

task2/part2/regression.py
task2/part2/predictions.csv
task2/part2/requirements.txt
